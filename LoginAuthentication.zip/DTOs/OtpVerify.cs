﻿namespace LoginAuthentication.DTOs
{
    public class OtpVerify
    {
        public string Email { get; set; }
        public string OtpCode { get; set; }
    }
}
