﻿namespace LoginAuthentication.DTOs
{
    public class OtpRequest
    {
        public string Email { get; set; }
    }
}
